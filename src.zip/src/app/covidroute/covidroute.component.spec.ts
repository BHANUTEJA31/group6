import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CovidrouteComponent } from './covidroute.component';

describe('CovidrouteComponent', () => {
  let component: CovidrouteComponent;
  let fixture: ComponentFixture<CovidrouteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CovidrouteComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CovidrouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
