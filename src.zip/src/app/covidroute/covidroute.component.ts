import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-covidroute',
  templateUrl: './covidroute.component.html',
  styleUrls: ['./covidroute.component.css']
})
export class CovidrouteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
