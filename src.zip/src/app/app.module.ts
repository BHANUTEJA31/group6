import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ContactComponent } from './contact/contact.component';
import { CovidloginComponent } from './covidlogin/covidlogin.component';
import { CovidregistrationComponent } from './covidregistration/covidregistration.component';
import { TimetableComponent } from './timetable/timetable.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { BookabedComponent } from './bookabed/bookabed.component';
import { AmbulanceComponent } from './ambulance/ambulance.component';
import { CovidfeedbackComponent } from './covidfeedback/covidfeedback.component';
import { CovidrouteComponent } from './covidroute/covidroute.component';
import { FormsModule } from '@angular/forms';

const appRoutes: Routes = [
  { path: 'CovidLogin', component: CovidloginComponent },
  { path: 'Covidregistration', component: CovidregistrationComponent },
  { path: 'Timetable', component: TimetableComponent },
  { path: 'Appointment', component: AppointmentComponent },
  { path: 'Bookabed', component: BookabedComponent },
  { path: 'Ambulance', component: AmbulanceComponent },
  { path: 'Covidfeedback', component: CovidfeedbackComponent },
  { path: 'Covidroute', component: CovidrouteComponent },
];

@NgModule({
  declarations: [
    AppComponent,

    CovidloginComponent,
    CovidregistrationComponent,
    TimetableComponent,
    AppointmentComponent,
    BookabedComponent,
    AmbulanceComponent,
    CovidfeedbackComponent,
    CovidrouteComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
  ],
  providers: [],
  bootstrap: [CovidrouteComponent],
})
export class AppModule {}
