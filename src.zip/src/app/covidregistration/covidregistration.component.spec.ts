import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CovidregistrationComponent } from './covidregistration.component';

describe('CovidregistrationComponent', () => {
  let component: CovidregistrationComponent;
  let fixture: ComponentFixture<CovidregistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CovidregistrationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CovidregistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
