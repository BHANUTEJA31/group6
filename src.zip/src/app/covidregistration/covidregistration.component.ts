import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-covidregistration',
  templateUrl: './covidregistration.component.html',
  styleUrls: ['./covidregistration.component.css']
})
export class CovidregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
