import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ambulance',
  templateUrl: './ambulance.component.html',
  styleUrls: ['./ambulance.component.css']
})
export class AmbulanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
