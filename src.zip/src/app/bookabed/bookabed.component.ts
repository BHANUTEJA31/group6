import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookabed',
  templateUrl: './bookabed.component.html',
  styleUrls: ['./bookabed.component.css']
})
export class BookabedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
