import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookabedComponent } from './bookabed.component';

describe('BookabedComponent', () => {
  let component: BookabedComponent;
  let fixture: ComponentFixture<BookabedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookabedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BookabedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
