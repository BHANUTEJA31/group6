import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CovidloginComponent } from './covidlogin.component';

describe('CovidloginComponent', () => {
  let component: CovidloginComponent;
  let fixture: ComponentFixture<CovidloginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CovidloginComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CovidloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
