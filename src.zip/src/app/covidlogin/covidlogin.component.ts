import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-covidlogin',
  templateUrl: './covidlogin.component.html',
  styleUrls: ['./covidlogin.component.css']
})
export class CovidloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
