import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-covidfeedback',
  templateUrl: './covidfeedback.component.html',
  styleUrls: ['./covidfeedback.component.css']
})
export class CovidfeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
