import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CovidfeedbackComponent } from './covidfeedback.component';

describe('CovidfeedbackComponent', () => {
  let component: CovidfeedbackComponent;
  let fixture: ComponentFixture<CovidfeedbackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CovidfeedbackComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CovidfeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
